#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include<math.h>
#include <time.h>
#include <bits/stdc++.h>
#include "include/BmpLoader.h"

using namespace std;

double windowHeight=1920, windowWidth=1080;
GLfloat alpha = 0.0, theta = 0.0, axis_x=0.0, axis_y=0.0, fan_rot=360.0, f_x=0.0, f_y = 0.0, rot = 0.0, d_rot = 0.0, d_x=0.0, d_y=0.0, p_rot=0.0;
GLboolean bRotate = false, uRotate = false, fanRotate = false, dRotate = false,  dkRotate=false, gRotate = false, pRotate=false;
GLfloat  eye_x =5, eye_y = 10, eye_z = 120, look_x=15, look_y=0.0, tx=-13, ty=-2.8, tz=0.0, tr_rot=0, ms=0.0, mb=0.0;
GLboolean AL = false, DL = false, SL = false, L0=false, L1 = false, L2 = false;
unsigned int TID[15] = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 15};
unsigned int td = 3;

const double PI = 3.1416;


/* GLUT callback Handlers */

int wired=0;
const int L=20;
const int dgre=3;
int ncpt=L+1;
const int nt = 40;				//number of slices along x-direction
const int ntheta = 20;


GLfloat ctrlpoints[L+1][3] =
{
    { 0.0, 0.0, 0.0}, { 0.2, 1.5, 0.0},
    { 0.4, 2.0, 0.0},{ 0.7, 2.2, 0.0},
    {1.0, 2.3, 0.0}, {1.4, 3.4, 0.0},
    {1.8, 3.4, 0.0},{2.2, 4.4, 0.0},
    {2.6, 4.5, 0.0}, {3.0, 4.4, 0.0},
    {3.4, 5.4, 0.0},{3.8, 5.4, 0.0},
    {4.2, 5.4, 0.0},{4.6, 5.4, 0.0},
    {5.0, 5.5, 0.0},{5.4, 5.5, 0.0},
    {5.8, 5.5, 0.0},{6.2, 5.5, 0.0},
    {6.6, 5.5, 0.0},{7.2, 5.2, 0.0},
    {6.8, 5.52, 0.0}
};


//control points
long long nCr(int n, int r)
{
    if(r > n / 2)
        r = n - r; // because C(n, r) == C(n, n - r)
    long long ans = 1;
    int i;

    for(i = 1; i <= r; i++)
    {
        ans *= n - r + i;
        ans /= i;
    }

    return ans;
}

//polynomial interpretation for N points
void BezierCurve ( double t,  float xy[2])
{
    double y=0;
    double x=0;
    t=t>1.0?1.0:t;
    for(int i=0; i<=L; i++)
    {
        int ncr=nCr(L,i);
        double oneMinusTpow=pow(1-t,double(L-i));
        double tPow=pow(t,double(i));
        double coef=oneMinusTpow*tPow*ncr;
        x+=coef*ctrlpoints[i][0];
        y+=coef*ctrlpoints[i][1];

    }
    xy[0] = float(x);
    xy[1] = float(y);

    //return y;
}


static GLfloat v_pyramid[5][3] =
{
    {0.0, 0.0, 0.0},  //point index 0
    {0.0, 0.0, 2.0},  //point index 1
    {2.0, 0.0, 2.0},  //point index 2
    {2.0, 0.0, 0.0},  //point index 3
    {1.0, 4.0, 1.0}   //point index 4
};

static GLubyte p_Indices[4][3] =
{
    {4, 1, 2}, // indices for drawing the triangle plane 1
    {4, 2, 3}, // indices for drawing the triangle plane 2
    {4, 3, 0}, // indices for drawing the triangle plane 3
    {4, 0, 1}  // indices for drawing the triangle plane 4
};

static GLubyte quadIndices[1][4] =
{
    {0, 3, 2, 1}
};  // indeces for drawing the quad plane

static GLfloat v_cube[8][3] =
{
    {0.0, 0.0, 0.0},  //point index 0
    {2.0, 0.0, 0.0},  //point index 1
    {2.0, 0.0, 2.0},  //point index 2
    {0.0, 0.0, 2.0},  //point index 3
    {0.0, 2.0, 0.0},  //point index 4
    {2.0, 2.0, 0.0},  //point index 5
    {2.0, 2.0, 2.0},  //point index 6
    {0.0, 2.0, 2.0}   //point index 7

};

static GLubyte hexIndices[6][4] =
{
    {0, 1, 5, 4}, // indices for drawing the quad plane 1
    {1, 2, 6, 5}, // indices for drawing the quad plane 2
    {2, 3, 7, 6}, // indices for drawing the quad plane 3
    {3, 0, 4, 7},  // indices for drawing the quad plane 4
    {0, 1, 2, 3}, // indices for drawing the quad plane 5
    {4, 5, 6, 7}  // indices for drawing the quad plane 6
};

/*static GLfloat colors[6][3] =
{
    {0.0, 0.0, 1.0},  //color for point index 0
    {0.5, 0.0, 1.0},  //color for point index 1
    {0.0, 1.0, 0.0},  //color for point index 2
    {0.0, 1.0, 1.0},  //color for point index 3
    {0.8, 0.0, 0.0},  //color for point index 4
    {0.5, 1.0, 0.5}  //color for point index 5
};
*/

static void getNormal3p(GLfloat x1, GLfloat y1,GLfloat z1, GLfloat x2, GLfloat y2,GLfloat z2, GLfloat x3, GLfloat y3,GLfloat z3)
{
    GLfloat Ux, Uy, Uz, Vx, Vy, Vz, Nx, Ny, Nz;

    Ux = x2-x1;
    Uy = y2-y1;
    Uz = z2-z1;

    Vx = x3-x1;
    Vy = y3-y1;
    Vz = z3-z1;

    Nx = Uy*Vz - Uz*Vy;
    Ny = Uz*Vx - Ux*Vz;
    Nz = Ux*Vy - Uy*Vx;

    glNormal3f(Nx,Ny,Nz);
}

void setNormal(GLfloat x1, GLfloat y1,GLfloat z1, GLfloat x2, GLfloat y2,GLfloat z2, GLfloat x3, GLfloat y3,GLfloat z3)
{
    GLfloat Ux, Uy, Uz, Vx, Vy, Vz, Nx, Ny, Nz;

    Ux = x2-x1;
    Uy = y2-y1;
    Uz = z2-z1;

    Vx = x3-x1;
    Vy = y3-y1;
    Vz = z3-z1;

    Nx = Uy*Vz - Uz*Vy;
    Ny = Uz*Vx - Ux*Vz;
    Nz = Ux*Vy - Uy*Vx;

    glNormal3f(-Nx,-Ny,-Nz);
}

void bottleBezier()
{
    int i, j;
    float x, y, z, r;				//current coordinates
    float x1, y1, z1, r1;			//next coordinates
    float theta;

//    const float startx = 0, endx = ctrlpoints[L][0];
    //number of angular slices
//    const float dx = (endx - startx) / nt;	//x step size
    const float dtheta = 2*PI / ntheta;		//angular step size

    float t=0;
    float dt=1.0/nt;
    float xy[2];
    BezierCurve( t,  xy);
    x = xy[0];
    r = xy[1];
    //rotate about z-axis
    float p1x,p1y,p1z,p2x,p2y,p2z;
    for ( i = 0; i < nt; ++i )  			//step through x
    {
        theta = 0;
        t+=dt;
        BezierCurve( t,  xy);
        x1 = xy[0];
        r1 = xy[1];

        //draw the surface composed of quadrilaterals by sweeping theta
        glBegin( GL_QUAD_STRIP );
        for ( j = 0; j <= ntheta; ++j )
        {
            theta += dtheta;
            double cosa = cos( theta );
            double sina = sin ( theta );
            y = r * cosa;
            y1 = r1 * cosa;	//current and next y
            z = r * sina;
            z1 = r1 * sina;	//current and next z

            //edge from point at x to point at next x
            glVertex3f (x, y, z);

            if(j>0)
            {
                setNormal(p1x,p1y,p1z,p2x,p2y,p2z,x, y, z);
            }
            else
            {
                p1x=x;
                p1y=y;
                p1z=z;
                p2x=x1;
                p2y=y1;
                p2z=z1;

            }
            glVertex3f (x1, y1, z1);

            //forms quad with next pair of points with incremented theta value
        }
        glEnd();
        x = x1;
        r = r1;
    } //for i

}


void drawpyramid(float col_a,float col_b,float col_c)
{

    GLfloat mat_ambient[] = { col_a*0.6, col_b*0.6, col_c*0.6, 1.0 };
    GLfloat mat_diffuse[] = {  col_a, col_b, col_c, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};

    glMaterialfv( GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv( GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess);

    //glColor3f(col_a,col_b,col_c);
    glBegin(GL_TRIANGLES);

    for (GLint i = 0; i <4; i++)
    {
        //glColor3f(colors[i][0],colors[i][1],colors[i][2]);
        getNormal3p(v_pyramid[p_Indices[i][0]][0], v_pyramid[p_Indices[i][0]][1], v_pyramid[p_Indices[i][0]][2],
                    v_pyramid[p_Indices[i][1]][0], v_pyramid[p_Indices[i][1]][1], v_pyramid[p_Indices[i][1]][2],
                    v_pyramid[p_Indices[i][2]][0], v_pyramid[p_Indices[i][2]][1], v_pyramid[p_Indices[i][2]][2]);

        //glColor3fv(&colors[i][0]);
        glVertex3fv(&v_pyramid[p_Indices[i][0]][0]);
        glTexCoord2f(1,1);
        glVertex3fv(&v_pyramid[p_Indices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&v_pyramid[p_Indices[i][2]][0]);
        glTexCoord2f(0,0);
    }
    glEnd();

    glBegin(GL_QUADS);

    for (GLint i = 0; i <1; i++)
    {
        //glColor3f(colors[4][0],colors[4][1],colors[4][2]);
        getNormal3p(v_pyramid[quadIndices[i][0]][0], v_pyramid[quadIndices[i][0]][1], v_pyramid[quadIndices[i][0]][2],
                    v_pyramid[quadIndices[i][1]][0], v_pyramid[quadIndices[i][1]][1], v_pyramid[quadIndices[i][1]][2],
                    v_pyramid[quadIndices[i][2]][0], v_pyramid[quadIndices[i][2]][1], v_pyramid[quadIndices[i][2]][2]);

        glVertex3fv(&v_pyramid[quadIndices[i][0]][0]);
        glTexCoord2f(1,1);
        glVertex3fv(&v_pyramid[quadIndices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&v_pyramid[quadIndices[i][2]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&v_pyramid[quadIndices[i][3]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();

}

void drawCube(float col_a,float col_b,float col_c)
{
    GLfloat mat_ambient[] = { col_a*0.6, col_b*0.6, col_c*0.6, 1.0 };
    GLfloat mat_diffuse[] = {  col_a, col_b, col_c, 1.0 };
    GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat mat_shininess[] = {60};

    glMaterialfv( GL_FRONT, GL_AMBIENT, mat_ambient);
    glMaterialfv( GL_FRONT, GL_DIFFUSE, mat_diffuse);
    glMaterialfv( GL_FRONT, GL_SPECULAR, mat_specular);
    glMaterialfv( GL_FRONT, GL_SHININESS, mat_shininess);

    //glColor3f(col_a,col_b,col_c);
    glBegin(GL_QUADS);

    for (GLint i = 0; i <6; i++)
    {
        //        glColor3f(colors[i][0],colors[i][1],colors[i][2]);
        getNormal3p(v_cube[hexIndices[i][0]][0], v_cube[hexIndices[i][0]][1], v_cube[hexIndices[i][0]][2],
                    v_cube[hexIndices[i][1]][0], v_cube[hexIndices[i][1]][1], v_cube[hexIndices[i][1]][2],
                    v_cube[hexIndices[i][2]][0], v_cube[hexIndices[i][2]][1], v_cube[hexIndices[i][2]][2]);

        glVertex3fv(&v_cube[hexIndices[i][0]][0]);
        glTexCoord2f(1,1);
        glVertex3fv(&v_cube[hexIndices[i][1]][0]);
        glTexCoord2f(1,0);
        glVertex3fv(&v_cube[hexIndices[i][2]][0]);
        glTexCoord2f(0,0);
        glVertex3fv(&v_cube[hexIndices[i][3]][0]);
        glTexCoord2f(0,1);
    }
    glEnd();
    //glutSolidSphere (3.0, 20, 16);

}

void ownTranslatef(GLfloat dx, GLfloat dy, GLfloat dz)
{

    GLfloat m[16];

    m[0] = 1;
    m[4] = 0;
    m[8] = 0;
    m[12] = dx;
    m[1] = 0;
    m[5] = 1;
    m[9] = 0;
    m[13] = dy;
    m[2] = 0;
    m[6] = 0;
    m[10] = 1;
    m[14] = dz;
    m[3] = 0;
    m[7] = 0;
    m[11] = 0;
    m[15] = 1;

    glMatrixMode(GL_MODELVIEW);
    glMultMatrixf(m);
}

void light()
{
    //1st light(Spotlight)---white
    GLfloat no_light[] = { 0.1, 0.1, 0.1, 1.0 };
    GLfloat light_ambient[]  = {0.6, 0.6, 0.6, 1.0};
    GLfloat light_diffuse[]  = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
    GLfloat light_position[] = {-120,20,80, 1.0 };

    if(AL)
        glLightfv( GL_LIGHT0, GL_AMBIENT, light_ambient);
    else
        glLightfv( GL_LIGHT0, GL_AMBIENT, no_light);

    if(DL)
        glLightfv( GL_LIGHT0, GL_DIFFUSE, light_diffuse);
    else
        glLightfv( GL_LIGHT0, GL_DIFFUSE, no_light);

    if(SL)
        glLightfv( GL_LIGHT0, GL_SPECULAR, light_specular);
    else
        glLightfv( GL_LIGHT0, GL_SPECULAR, no_light);

    glLightfv( GL_LIGHT0, GL_POSITION, light_position);


    GLfloat spot_direction[] = { 1.0, 0.0, 0.0 };
    glLightfv(GL_LIGHT0, GL_SPOT_DIRECTION, spot_direction);
    glLightf( GL_LIGHT0, GL_SPOT_CUTOFF, 70);


    //2nd light(Spotlight)---white
    GLfloat light_position2[] = {100,20,80, 1.0 };

    if(AL)
        glLightfv( GL_LIGHT1, GL_AMBIENT, light_ambient);
    else
        glLightfv( GL_LIGHT1, GL_AMBIENT, no_light);

    if(DL)
        glLightfv( GL_LIGHT1, GL_DIFFUSE, light_diffuse);
    else
        glLightfv( GL_LIGHT1, GL_DIFFUSE, no_light);

    if(SL)
        glLightfv( GL_LIGHT1, GL_SPECULAR, light_specular);
    else
        glLightfv( GL_LIGHT1, GL_SPECULAR, no_light);

    glLightfv( GL_LIGHT1, GL_POSITION, light_position2);


    GLfloat spot_direction2[] = { -1.0, 0.0, 0.0 };
    glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, spot_direction2);
    glLightf( GL_LIGHT1, GL_SPOT_CUTOFF, 70);


    //......................3rd light(SUN).........................YELLOW
    GLfloat light_ambient3[]  = {0.6, 0.6, 0.0, 1.0};
    GLfloat light_diffuse3[]  = { 1.0, 1.0, 0.0, 1.0 };
    GLfloat light_position3[] = { -10.0,50.0,80.0, 1.0 };

    if(AL)
        glLightfv( GL_LIGHT2, GL_AMBIENT, light_ambient3);
    else
        glLightfv( GL_LIGHT2, GL_AMBIENT, no_light);

    if(DL)
        glLightfv( GL_LIGHT2, GL_DIFFUSE, light_diffuse3);
    else
        glLightfv( GL_LIGHT2, GL_DIFFUSE, no_light);

    if(SL)
        glLightfv( GL_LIGHT2, GL_SPECULAR, light_specular);
    else
        glLightfv( GL_LIGHT2, GL_SPECULAR, no_light);

    glLightfv( GL_LIGHT2, GL_POSITION, light_position3);

}

void LoadTexture(const char*filename, unsigned int *ID)
{
    glGenTextures(1, ID);
    glBindTexture(GL_TEXTURE_2D, *ID);
    glPixelStorei(GL_UNPACK_ALIGNMENT, *ID);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    BmpLoader bl(filename);
    gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGB, bl.iWidth, bl.iHeight, GL_RGB, GL_UNSIGNED_BYTE, bl.textureData );
}

void wall_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix(); //...........begin of walls..............

    //road part
    glPushMatrix();//back
    glTranslatef(-30,-3,-150);
    glScalef(65.2,0.2,55);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//right
    glTranslatef(54.2,-3,-40);
    glScalef(23,0.2,45);
    drawCube(1,1,1);
    glPopMatrix();

    //ground
    glPushMatrix();
    glTranslatef(-30,-3,-29.5);
    glScalef(37,0.2,40);
    drawCube(1,1,1);
    glPopMatrix();


    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[6]);
    glTranslatef(-4,0,5);

    //wall1
    glPushMatrix();
    glTranslatef(-25,-3,-20);
    glScalef(30,2,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    //wall2
    glPushMatrix();
    glTranslatef(-25,-3,-20);
    glScalef(0.05,2,25);
    drawCube(1,1,1);
    glPopMatrix();

    //wall3_1
    glPushMatrix();
    glTranslatef(35,-3,-20);
    glScalef(0.05,2,11);
    drawCube(1,1,1);
    glPopMatrix();

    //wall3_2
    glPushMatrix();
    glTranslatef(35,-3,8);
    glScalef(0.05,2,11);
    drawCube(1,1,1);
    glPopMatrix();

    //wall4_1
    glPushMatrix();
    glTranslatef(-25,-3,30);
    glScalef(15,2,0.05);
    drawCube(1,1,1);
    glPopMatrix();
    //wall4_2
    glPushMatrix();
    glTranslatef(15,-3,30);
    glScalef(10,2,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //glPopMatrix();
}


void moi_help()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);

    glPushMatrix();
    glTranslatef(0,-3,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2,-3,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();


    glPushMatrix();
    glTranslatef(0,-3,0);
    glScalef(1.2,0.1,0.2);
    for(int i = 3; i<44; i+=10)
    {
        glPushMatrix();
        glTranslatef(0,i,0);
        drawCube(1,1,1);
        glPopMatrix();
    }
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}

void moi_func_advanced()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix();

    glPushMatrix();
    moi_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,-6);
    moi_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,2,-2);
    glScalef(1,1,1.2);
    glRotated(90,1,0,0);
    moi_help();
    glPopMatrix();

    // glPopMatrix();
}

void moi_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix();

    glPushMatrix();
    moi_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,-6);
    moi_help();
    glPopMatrix();


    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(0,1.8,-5.9);
    glScalef(1.2,0.1,3.1);
    drawCube(1,1,1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //glPopMatrix();
}

void sliding_moi_func()
{
    //glViewport(0, 0, windowHeight, windowWidth);

    //glPushMatrix();

    glPushMatrix();
    moi_help();
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(0,1.8,0);
    glScalef(1.2,0.1,1);
    drawCube(1,1,1);
    glPopMatrix();


    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(0,2,2);
    glRotatef(140,1,0,0);
    glScalef(1.2,3,0.1);
    drawCube(1,1,1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //glPopMatrix();
}

void dolna_stand_func()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    //front triangle
    glPushMatrix();

    glPushMatrix();
    glRotatef(15, 0, 0, 1);
    glTranslatef(0,-3,0);
    glScalef(0.2,1.3,0.2);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(-15, 0, 0, 1);
    glTranslatef(-1,-3,0);
    glScalef(0.2,1.3,0.2);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPopMatrix();

    //back triangle
    glPushMatrix();
    glTranslatef(0,0,-5);

    glPushMatrix();
    glRotatef(15, 0, 0, 1);
    glTranslatef(0,-3,0);
    glScalef(0.2,1.3,0.2);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(-15, 0, 0, 1);
    glTranslatef(-1,-3,0);
    glScalef(0.2,1.3,0.2);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPopMatrix();

    //upper rod
    glPushMatrix();
    glTranslatef(-0.4,1.9,-4.8);
    glScalef(0.1, 0.1, 2.5);
    drawCube(1,1,1);
    glPopMatrix();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}

void dolna_sitting_place_func()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[0]);
    //connector
    glPushMatrix();
    glTranslatef(-1.5,0,-0.4);
    glScalef(1,0.5,0.5);
    drawpyramid(1,1,1);
    glPopMatrix();

    //sitting place
    glPushMatrix();
    glRotatef( rot, d_x, d_y, 0.0 );

    //hanging stand
    glPushMatrix();

    glPushMatrix();
    glRotatef(10, 0, 0, 1);
    glTranslatef(0,-3,0);
    glScalef(0.1,0.8,0.1);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glRotatef(-10, 0, 0, 1);
    glTranslatef(-1,-3,0);
    glScalef(0.1,0.8,0.1);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPopMatrix();

    //flat
    glPushMatrix();
    glTranslatef(-2,-3,-1);
    glScalef(1.5,0.2,1);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void dolna_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix();//...............dolna............

    glPushMatrix();
    glTranslatef(1,0,-0.3);
    glRotatef(90,0,1,0);
    dolna_stand_func();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,0);
    glScalef(0.5,1,1);
    dolna_sitting_place_func();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2,0,0);
    glScalef(0.5,1,1);
    dolna_sitting_place_func();
    glPopMatrix();

    //glPopMatrix();//.................end dolna............

}

void dheki_sitting_place()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);

    //one side
    glPushMatrix();
    //handle
    glPushMatrix();
    glTranslatef(-1.2,0,0);

    glPushMatrix();
    glTranslatef(2.5,-2,0);
    glScalef(0.2, 0.7, 0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-2,1);
    glScalef(0.2, 0.7, 0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-1,0);
    glScalef(0.2, 0.2, 0.7);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();


    //stand
    glPushMatrix();
    glTranslatef(-2.5,-3,1.4);
    glScalef(1, 0.7, 1);
    glRotatef(180,1,0,0);

    glPushMatrix();
    glTranslatef(2.5,-2,0);
    glScalef(0.2, 1.2, 0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-2,1);
    glScalef(0.2, 1.2, 0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-0.5,0);
    glScalef(0.2, 0.2, 0.7);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();

    //flat
    glPushMatrix();
    glTranslatef(-0.1,-2.1,-0.1);
    glScalef(1, 0.3, 0.8);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void dheki_side()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);

    glPushMatrix();
    glTranslatef(2.5,-3,0);
    glScalef(0.2, 1.5, 0.3);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-3,1);
    glScalef(0.2, 1.5, 0.3);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,-1,0);
    glScalef(0.2, 0.3, 0.6);
    drawCube(1,1,1);
    glPopMatrix();


    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}

void celling_fan()
{
    glViewport(0, 0, windowHeight, windowWidth);

    glPushMatrix();    //............begin of celling fan................

    //middle rod
    glPushMatrix();
    glTranslatef(-0.3, 0.2, -0.3);
    glScalef(0.3,0.5,0.3);
    drawCube(1,1,1);
    glPopMatrix();

//middle bar
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-1, -0.2, -1);
    glScalef(1,0.2,1);
    drawCube(1,1,1);
    glPopMatrix();


    //left-right wing
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-5.5, 0, -0.5);
    glScalef(6,0.05,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    //front-back wing
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-0.5, 0, -5.5);
    glScalef(0.5,0.05,6);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix(); //............end of celling fan................


}

void almirah()
{
    glViewport(0, 0, windowHeight, windowWidth);
    glPushMatrix(); //....................................begin of almirah.................................
//almirah
    glPushMatrix();
    glTranslatef(-7.3,-2.8,-1.5);
    glScalef(0.5,3,1.5);
    drawCube(1,1,1);
    glPopMatrix();

    //almirah row1
    glPushMatrix();
    glTranslatef(-6.3,-2.8,-1.5);
    glScalef(0.05,0.05,1.5);
    drawCube(1,1,1);
    glPopMatrix();

    //almirah row2
    glPushMatrix();
    glTranslatef(-6.3,3.1,-1.5);
    glScalef(0.05,0.05,1.5);
    drawCube(1,1,1);
    glPopMatrix();

    //almirah col1
    glPushMatrix();
    glTranslatef(-6.3,-2.8,-1.5);
    glScalef(0.05,3,0.05);
    drawCube(1,1,1);
    glPopMatrix();
    //almirah col2
    glPushMatrix();
    glTranslatef(-6.3,-2.8,-0.2);
    glScalef(0.05,3,0.05);
    drawCube(1,1,1);
    glPopMatrix();
    //almirah handle1
    glPushMatrix();
    glTranslatef(-6.2,0,-0.3);
    glScalef(0.05,0.5,0.05);
    drawCube(1,1,1);
    glPopMatrix();
    //almirah handle2
    glPushMatrix();
    glTranslatef(-6.2,0,0.1);
    glScalef(0.05,0.5,0.05);
    drawCube( 1.0, 1.0, 1.0);
    glPopMatrix();

    //almirah col3
    glPushMatrix();
    glTranslatef(-6.3,-2.8,0);
    glScalef(0.05,3,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    //almirah col4
    glPushMatrix();
    glTranslatef(-6.3,-2.8,1.4);
    glScalef(0.05,3,0.05);
    drawCube(1,1,1);
    glPopMatrix();
    glPopMatrix();
}

void chair()
{
    glPushMatrix(); //........begin of chair .......
    glTranslated(2,0,1);
    //bottom FLAT
    glPushMatrix();
    glTranslatef(0,-1,-0.5);
    glRotatef(90,1,0,0);
    glScalef(2.5,2.3,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    //side FLAT
    glPushMatrix();
    glTranslatef(0,-1,4);
    glScalef(2.5,2.2,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    //back left leg
    glPushMatrix();
    glTranslatef(0,-1,0);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //back right leg
    glPushMatrix();
    glTranslatef(4.5,-1,0);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //front left leg
    glPushMatrix();
    glTranslatef(0,-1,4);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //front right leg
    glPushMatrix();
    glTranslatef(4.5,-1,4);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix(); //..........end of chair........
}

void table()
{
    glViewport(0, 0, windowHeight, windowWidth);

    glPushMatrix();    //.......begin of table.......

    //FLAT
    glPushMatrix();
    glTranslatef(0,0,-0.5);
    glRotatef(90,1,0,0);
    glScalef(4.2,2.2,0.05);
    drawCube(1,1,1);
    glPopMatrix();

    //back left leg
    glPushMatrix();
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //back right leg
    glPushMatrix();
    glTranslatef(8,0,0);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //front left leg
    glPushMatrix();
    glTranslatef(0,0,4);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //front right leg
    glPushMatrix();
    glTranslatef(8,0,4);
    glRotatef(180,1,0,0);
    glScalef(0.2,2.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //left leg connector
    glPushMatrix();
    glTranslatef(0,-4,0);
    glRotatef(90,1,0,0);
    glScalef(0.2,2,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //right leg connector
    glPushMatrix();
    glTranslatef(8,-4,0);
    glRotatef(90,1,0,0);
    glScalef(0.2,2,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //connect connector
    glPushMatrix();
    glTranslatef(0,-4,2);
    glScalef(4,0.2,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();      //......end of table

}

void room_func()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();

    glPushMatrix();//fridge
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(8,-2,5);
    glScalef(0.3,2,1);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//rack
    glTranslatef(-4.5,-1,3);
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    for(int i = 2; i>-1; i--)
    {
        glPushMatrix();
        glTranslatef(0,i,0);
        glScalef(0.5,0.05,1);
        drawCube(1,1,1);
        glPopMatrix();
    }

    for(int k = 0; k<2; k++)
    {
        for(int i = 0; i<3; i++)
        {
            glPushMatrix();
            glTranslatef(k,i,0);
            glScalef(0.05,0.05,1);
            drawCube(1,1,1);
            glPopMatrix();
        }
    }

    for(int k = 0; k<2; k++)
    {
        for(int i = 0; i<3; i++)
        {
            glPushMatrix();
            glTranslatef(k,-1,i);
            glScalef(0.05, 1.5, 0.05);
            drawCube(1,1,1);
            glPopMatrix();
        }
    }
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,-2,0);
    //bed
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[8]);
    glScalef(1.5,0.5,2);
    drawCube(1,1,1);
    glPopMatrix();

    //blanket
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[4]);
    glTranslatef(0,1,2);
    glScalef(1.5,0.08,1);
    drawCube(1,1,1);
    glPopMatrix();

    //balish
    for(float i = 0.2; i<3; i+=1.5)
    {
        glPushMatrix();
        glBindTexture(GL_TEXTURE_2D, TID[0]);
        glTranslatef(i,1,0.2);
        glScalef(0.5,0.08,0.5);
        drawCube(1,1,1);
        glPopMatrix();
    }
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(1.5,3,2);
    glScalef(0.5,0.5,0.5);
    celling_fan();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glTranslatef(-0.5,-0.5,1);
    glScalef(0.5,0.5,0.5);
    almirah();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3,0.5,-2);
    glBindTexture(GL_TEXTURE_2D, TID[9]);

    glPushMatrix();
    glTranslatef(2.5,0,2);
    glScalef(0.5,0.5,0.5);
    chair();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.5,0,2);
    glScalef(0.5,0.5,0.5);
    table();
    glPopMatrix();

    glPopMatrix();

    glPushMatrix();
    glTranslatef(-2,-2,8);
    glScalef(0.5,0.5,0.5);

    glPushMatrix();//tv-table
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(5,0,-5);
    glScalef(2,1.5,1);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//tv
    glBindTexture(GL_TEXTURE_2D, TID[1]);
    glTranslatef(5,3,-4);
    glScalef(2,1.5,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    for(float m = 5.5; m<8; m+=2)
    {
        glPushMatrix();//tv-stand
        glBindTexture(GL_TEXTURE_2D, TID[5]);
        glTranslatef(m,3,-5);
        glScalef(0.5,0.02,1);
        drawCube(1,1,1);
        glPopMatrix();
    }
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void building_help()
{

    //room-object
    glPushMatrix();
    glTranslatef(7,5,10);
    room_func();
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[4]);

    glPushMatrix();//front
    glTranslatef(0,0,20);
    glScalef(10,10,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//back
    glScalef(10,10,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//left
    glScalef(0.02,10,10);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//right
    glTranslatef(20,0,0);
    glScalef(0.02,10,10);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    //glDisable(GL_TEXTURE_2D);

    //windows
    //glEnable(GL_TEXTURE_2D);
    for(int k = 12; k>0; k-=5)
    {
        for(int i = 2; i<18; i+=3)
        {
            glPushMatrix();//front
            glBindTexture(GL_TEXTURE_2D, TID[10]);
            glTranslatef(i,k,21);
            glScalef(1,2,0.02);
            drawCube(1,1,1);
            glPopMatrix();
        }
    }

    for(int k = 12; k>0; k-=5)
    {
        for(int i = 2; i<18; i+=3)
        {
            glPushMatrix();//left
            glBindTexture(GL_TEXTURE_2D, TID[10]);
            glTranslatef(-0.1,k,i);
            glScalef(0.02,2,1);
            drawCube(1,1,1);
            glPopMatrix();
        }
    }

    glPushMatrix();//top
    glBindTexture(GL_TEXTURE_2D, TID[1]);
    glTranslatef(0,20,0);
    glScalef(10,0.02,10);
    drawCube(1,1,1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);


}

void building_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();


    for(int i = -30; i<100; i+=22)
    {
        glPushMatrix();
        glTranslatef(i,-3,-80);
        building_help();
        glPopMatrix();
    }

    for(int i = -36; i<35; i+=22)
    {
        glPushMatrix();
        glTranslatef(80,-3,i);
        building_help();
        glPopMatrix();
    }

    //glPopMatrix();
}

void dheki_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();//..........start.......

    //middle bar
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glTranslatef(-0.7,1.8,2.5);
    glRotatef(90,0,1,0);

    glPushMatrix();
    glTranslatef(2.5,-2.2,0.2);
    glScalef(0.2, 0.2, 1.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //side stand
    glPushMatrix();
    glTranslatef(-1, 0, -1);
    dheki_side();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-3, 0, -1);
    dheki_side();
    glPopMatrix();


    glPushMatrix();//..........begin moving part........
    glRotatef(d_rot, d_x, d_y, 0.0 );

    glPushMatrix();
    glTranslatef(0,2,3.2);
    glRotatef(90,0,1,0);

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glTranslatef(0,-2,0);
    glScalef(3, 0.2, 0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glTranslatef(0,-2,1);
    glScalef(3, 0.2, 0.2);
    drawCube(1,1,1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    glPushMatrix();
    dheki_sitting_place();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(6.5,0,1.4);
    glRotatef(180,0,1,0);
    dheki_sitting_place();
    glPopMatrix();

    glPopMatrix();

    glPopMatrix();

    //glPopMatrix();//............end.........
}

void bike_help()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    //head
    glPushMatrix();
    glTranslatef(0,0.1,0);
    glScalef(1,0.8,1);
    drawpyramid(1,1,1);
    glPopMatrix();

    //sitting place
    glPushMatrix();
    glScalef(2,0.5,1);
    drawCube(1,1,1);
    glPopMatrix();

    //handle
    glPushMatrix();
    glTranslatef(0.8, 1.7, 0);
    glScalef(0.2,0.2,1);
    drawCube(1,1,1);
    glPopMatrix();

    //feet-holder
    glPushMatrix();
    glTranslatef(0.8, 0.1, -0.5);
    glScalef(0.2,0.2,1.5);
    drawCube(1,1,1);
    glPopMatrix();

    //back-wall
    glPushMatrix();
    glTranslatef(4, 0, 0);
    glScalef(0.2,1.5,1);
    drawCube(1,1,1);
    glPopMatrix();

    //roof
    glPushMatrix();
    glTranslatef(0, 2.9, 0);
    glScalef(2,0.2,1);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void bike_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix();    //............begin of bike................

    glEnable(GL_TEXTURE_2D);

    //roof
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glTranslatef(-8, 1, -7);
    glScalef(8,0.5,8);
    drawpyramid(1,1,1);
    glPopMatrix();
    //glDisable(GL_TEXTURE_2D);


    //glEnable(GL_TEXTURE_2D);

    //ceil
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[4]);
    glTranslatef(-9, -9.2, -9);
    glScalef(9,0.2,9);
    drawpyramid(1,1,1);
    glPopMatrix();
//    glDisable(GL_TEXTURE_2D);
//
//    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[9]);
    //string1
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-5, -6, 0);
    glScalef(0.2,3,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //string2
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(5.5, -6, 0);
    glScalef(0.2,3,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //string3
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(0, -6, -5);
    glScalef(0.2,3,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //string4
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(0, -6, 5.5);
    glScalef(0.2,3,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    //middle rod
    glPushMatrix();
    glTranslatef(-0.3, -9.5, -0.3);
    glScalef(0.3,6,0.3);
    drawCube(1,1,1);
    glPopMatrix();

//middle bar
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-1, -0.2, -1);
    glScalef(1,0.2,1);
    drawCube(1,1,1);
    glPopMatrix();


    //left-right wing
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-5.5, 0, -0.5);
    glScalef(6,0.05,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    //front-back wing
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-0.5, 0, -5.5);
    glScalef(0.5,0.05,6);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //sitting place front
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-1.95,-9,4.7);
    bike_help();
    glPopMatrix();


    //sitting place back
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(2,-9,-3.8);
    glRotatef(180,0,1,0);
    bike_help();
    glPopMatrix();

    //sitting place right
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(4.8,-9,2);
    glRotatef(90,0,1,0);
    bike_help();
    glPopMatrix();


    //sitting place left
    glPushMatrix();
    glRotatef( fan_rot, f_x, f_y, 0.0 );
    glTranslatef(-3.8,-9,-2);
    glRotatef(270,0,1,0);
    bike_help();
    glPopMatrix();

    //glPopMatrix(); //-------------end of bike--------------

}

void sit_help()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);

    glPushMatrix();
    glScalef(2,1,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0.5,0.4);
    glScalef(2,0.2,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}

void ship_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();

    //up
    glPushMatrix();
    glScalef(6,3,2.5);
    drawpyramid(1,0,1);
    glPopMatrix();

//left
    glPushMatrix();
    glTranslatef(-5,0,0);
    glRotatef(45,0,0,1);
    glScalef(2,2,2.5);
    drawpyramid(1,1,1);
    glPopMatrix();

    //right
    glPushMatrix();
    glTranslatef(13,2.5,0);
    glRotatef(-45,0,0,1);
    glScalef(2,2,2.5);
    drawpyramid(1,1,1);
    glPopMatrix();

    //down
    glPushMatrix();
    glTranslatef(-7,-1,0);
    glScalef(12.5,2,2.5);
    drawCube(1,1,1);
    glPopMatrix();

    //glPopMatrix();
}

void call_ship_func()
{
    glEnable(GL_TEXTURE_2D);

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[5]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(-120,-3,ms);
    glRotatef(90,0,1,0);
    ship_func();
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[9]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(-100,-3,ms);
    glRotatef(90,0,1,0);
    ship_func();
    glPopMatrix();
    //glDisable(GL_TEXTURE_2D);
//boat
    //glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(-80,-3,mb-30);
    glScalef(0.5, 0.5,0.5);
    glRotatef(90,0,1,0);
    ship_func();
    glPopMatrix();
    // glDisable(GL_TEXTURE_2D);

    //boat
    //glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(-60,-3,mb-30);
    glScalef(0.5, 0.5,0.5);
    glRotatef(90,0,1,0);
    ship_func();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void sky_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//
//    glPushMatrix();//............

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[8]);

    glPushMatrix();//top
    glTranslatef(-142,190,-150);
    glScalef(125,0.02,100);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//building-back
    glTranslatef(-35,-10,-85);
    glScalef(70,50,0.02);
    //drawCube(1,0,0);
    glPopMatrix();

    glPushMatrix();//back
    glTranslatef(-142,-10,-150);
    glScalef(125,100,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//left
    glTranslatef(-140,-10,-150);
    glScalef(0.02,100,100);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//right
    glTranslatef(105,-10,-150);
    glScalef(0.02,100,100);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    //glDisable(GL_TEXTURE_2D);


    //glEnable(GL_TEXTURE_2D);
    glPushMatrix();//down
    glBindTexture(GL_TEXTURE_2D, TID[1]);

    glPushMatrix();
    glTranslatef(-142,-10.5,-150);
    glScalef(125,0.02,100);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//front down-wall
    glTranslatef(-35,-10.5,50.5);
    glScalef(70,4,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //glPopMatrix();
}

void peyala_help()
{
    glEnable(GL_TEXTURE_2D);

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[0]);
    glRotatef(90,0,0,1);
    glScalef(0.3, 0.6, 0.6);
    bottleBezier();
    glPopMatrix();

    glPushMatrix();//...start handle....
    glBindTexture(GL_TEXTURE_2D, TID[2]);

    glPushMatrix();
    // glTranslatef(0,0.2,0);

    glPushMatrix();
    glRotatef(65,0,0,1);
    glScalef(0.5,1.5,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//middle
    glTranslatef(-0.5,0,-0.4);
    glScalef(0.5,0.5,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,1,0);
    glRotatef(-70,0,0,1);
    glScalef(0.5,1.5,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();



    glPushMatrix();
    glRotatef(90,0,1,0);

    glPushMatrix();
    glRotatef(65,0,0,1);
    glScalef(0.5,1.5,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,1,0);
    glRotatef(-70,0,0,1);
    glScalef(0.5,1.5,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();

    glPopMatrix();//.............end handle....

    glDisable(GL_TEXTURE_2D);
}

void peyala_func()
{

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[6]);
    glTranslatef(7,-2.5,2);
    glScalef(7,0.02,7);
    drawCube(1,1,1);
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    for(int k = 5; k<15; k+=8)
    {
        for(int i = 10; i<20; i+=8)
        {
            glPushMatrix();
            glTranslatef(i,-2.2,k);
            glRotatef(p_rot,f_x,f_y,0);
            peyala_help();
            glPopMatrix();
        }
    }
}

void gari_tyre()
{
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[1]);

    glTranslatef(0, -0.3, 0);

    glPushMatrix();
    glScalef(0.1,0.2,0.2);
    bottleBezier();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(1.3,0,0);
    glRotatef(-180,0,1,0);
    glScalef(0.1,0.2,0.2);
    bottleBezier();
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void gari_func()
{
    //glViewport(0, 0, windowHeight, windowWidth);
    glPushMatrix();
    ownTranslatef(tx,ty,tz);
    glRotatef(tr_rot,0,1,0);

    glPushMatrix();
    sit_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,2);
    sit_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,4);
    sit_help();
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[0]);

    glPushMatrix();//front-ceil
    glTranslatef(0,1,6);
    glRotatef(25,1,0,0);
    glScalef(2,0.02,1.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//front-floor
    glTranslatef(0,0,4.2);
    glScalef(2,0.02,2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//front-window
    glTranslatef(0,0,6);
    glScalef(2,1,0.02);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//back
    glTranslatef(0,0,-0.2);
    glScalef(2,1.5,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//down
    glScalef(2,0.02,2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//left
    glTranslatef(-0.1,0,0);
    glScalef(0.02,1,2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();//front-left
    glTranslatef(-0.1,0,0.2);
    glScalef(0.02,0.5,4);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPushMatrix();//front-right
    glTranslatef(4,0,0.2);
    glScalef(0.02,0.5,4);
    drawpyramid(1,1,1);
    glPopMatrix();

    glPushMatrix();//right
    glTranslatef(4,0,0);
    glScalef(0.02,1,2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);


    glPushMatrix();
    gari_tyre();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.7,0,0);
    gari_tyre();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(0,0,6);
    gari_tyre();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(2.7,0,6);
    gari_tyre();
    glPopMatrix();

    glPopMatrix();
}

void railLine_help()
{
    glPushMatrix();
    glTranslatef(0.3,-2.9,-15);
    glScalef(0.2,0.2,20);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(3.2,-2.9,-15);
    glScalef(0.2,0.2,20);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    for(int i = -14; i<25; i++)
    {
        glPushMatrix();
        glTranslatef(0,-2.9,i);
        glScalef(2,0.2,0.2);
        drawCube(1,1,1);
        glPopMatrix();
    }
    glPopMatrix();

}

void railLine_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();

    glPushMatrix();
    glScalef(1,1,1.1);
    glTranslatef(-10,0,0);
    railLine_help();
    glPopMatrix();

    glPushMatrix();
    glScalef(1,1,1.1);
    glTranslatef(-23,0,0);
    railLine_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-16.1,0,-12);
    glScalef(0.41,1,1);
    glRotatef(90,0,1,0);
    railLine_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-16.1,0,28);
    glScalef(0.41,1,1);
    glRotatef(90,0,1,0);
    railLine_help();
    glPopMatrix();

    //glPopMatrix();
}

void road_help()
{
    glEnable(GL_TEXTURE_2D);

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[5]);
    drawCube(1,1,1);
    glPopMatrix();

    glDisable(GL_TEXTURE_2D);
}

void road_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();

    glPushMatrix();//back
    glTranslatef(-30,-2.6,-22);
    glScalef(37,0.05,3);
    road_help();
    glPopMatrix();

    glPushMatrix();//front
    glTranslatef(-30,-2.6,44);
    glScalef(31,0.05,3);
    road_help();
    glPopMatrix();

    glPushMatrix();//right
    glTranslatef(32,-2.6,50);
    glScalef(3,0.05,33);
    glRotatef(90,0,1,0);
    road_help();
    glPopMatrix();

    glPushMatrix();//river-right
    glTranslatef(64,-2.6,50);
    glScalef(5,0.05,48.5);
    glRotatef(90,0,1,0);
    road_help();
    glPopMatrix();

    glPushMatrix();//river-back
    glTranslatef(-30,-2.6,-57);
    glScalef(65,0.05,5);
    road_help();
    glPopMatrix();

    glPushMatrix();//left
    glTranslatef(-36,-2.8,50.5);
    glScalef(3,0.05,100);
    glRotatef(90,0,1,0);
    road_help();
    glPopMatrix();

    //glPopMatrix();

}

void river_help()
{

    glEnable(GL_TEXTURE_2D);

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[td]);
    glTranslatef(-30,-10,-10);
    glScalef(37,3,5);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);

    glPushMatrix();
    glTranslatef(-30,-10,-10.2);
    glScalef(37,4,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPushMatrix();
    glTranslatef(-30,-10,0);
    glScalef(37,4,0.2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);
}

void river_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();


    glPushMatrix();//back-river
    glTranslatef(0,0,-30);
    river_help();
    glPopMatrix();

    glPushMatrix();//left-river
    glTranslatef(-40,0,-28);
    glScalef(10,1,2.65);
    glRotatef(90,0,1,0);
    river_help();
    glPopMatrix();

    glEnable(GL_TEXTURE_2D);

    //floor-small
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[3]);
    glTranslatef(43.5,-10,-40);
    glScalef(5.5,3,5);
    drawCube(1,1,1);
    glPopMatrix();
//    glDisable(GL_TEXTURE_2D);
//
//    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[7]);

    //back-small
    glPushMatrix();
    glTranslatef(43.5,-10,-40.2);
    glScalef(5.5,4,0.2);
    drawCube(1,1,1);
    glPopMatrix();
    //right-small
    glPushMatrix();
    glTranslatef(54,-10,-40);
    glScalef(0.2,4,5);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);


    glPushMatrix();//right-river
    glTranslatef(54,0,17.5);
    glScalef(1,1,1.08);
    glRotatef(90,0,1,0);
    river_help();
    glPopMatrix();


    //glPopMatrix();

}

void bridge_help()
{
    glEnable(GL_TEXTURE_2D);

    //middle-floor
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glScalef(2,0.5,7);
    drawCube(1,1,1);
    glPopMatrix();
//    glDisable(GL_TEXTURE_2D);
//
//    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[0]);

    //side-left
    glPushMatrix();
    glTranslatef(0,1,0);
    glScalef(0.2,1,7);
    drawCube(1,1,1);
    glPopMatrix();

    //side-right
    glPushMatrix();
    glTranslatef(3.5,1,0);
    glScalef(0.2,1,7);
    drawCube(1,1,1);
    glPopMatrix();

    //back-stand
    glPushMatrix();
    glTranslatef(0,-2,0);
    glScalef(2,1,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    //front-stand
    glPushMatrix();
    glTranslatef(0,-2,13);
    glScalef(2,1,0.5);
    drawCube(1,1,1);
    glPopMatrix();

    //front-stand
    glPushMatrix();
    glTranslatef(0,-0.4,13.2);
    glRotatef(20,1,0,0);
    glScalef(2,0.8,3);
    drawCube(1,1,1);
    glPopMatrix();

    //back-stand
    glPushMatrix();
    glTranslatef(0,1,0);
    glRotatef(155,1,0,0);
    glScalef(2,0.8,2);
    drawCube(1,1,1);
    glPopMatrix();

    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

}

void bridge_func()
{
//    glViewport(0, 0, windowHeight, windowWidth);
//    glPushMatrix();

    //back
    glPushMatrix();
    glTranslatef(-5,-1.5,-41.5);
    glScalef(2,0.5,1);
    bridge_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(12,-1.5,-41.5);
    glScalef(2,0.5,1);
    bridge_help();
    glPopMatrix();

    //right
    glPushMatrix();
    glTranslatef(42,-1.5,0);
    glRotatef(90,0,1,0);
    glScalef(2,0.5,1);
    bridge_help();
    glPopMatrix();

    glPushMatrix();
    glTranslatef(42,-1.5,50);
    glRotatef(90,0,1,0);
    glScalef(2,0.5,1);
    bridge_help();
    glPopMatrix();

    // glPopMatrix();

}

void display(void)
{
    glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);

    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();

    glFrustum(-5,5,-5,5, 4,500);

    glMatrixMode( GL_MODELVIEW );
    glLoadIdentity();
    // eye, look at, head up vector
    gluLookAt(eye_x, eye_y, eye_z, look_x, look_y, 0, 0, 1, 0);
    glViewport(0, 0, windowHeight, windowWidth);

    if(wired)
    {
        glPolygonMode( GL_FRONT, GL_LINE ) ;
        glPolygonMode( GL_BACK, GL_LINE ) ;
    }
    else
    {
        glPolygonMode( GL_FRONT,GL_FILL ) ;
        glPolygonMode( GL_BACK, GL_FILL ) ;
    }

    glPushMatrix();
    glTranslatef(0,0,70);

    //peyala
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    peyala_func();
    glPopMatrix();

    //ship
    glPushMatrix();
    call_ship_func();
    glPopMatrix();

    //wall
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[1]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    wall_func();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //building
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    building_func();
    glPopMatrix();

    //gari
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(0,1,0);
    glScalef(1,1,0.8);
    gari_func();
    glPopMatrix();

    //railLine
    glEnable(GL_TEXTURE_2D);
    glPushMatrix();
    glBindTexture(GL_TEXTURE_2D, TID[2]);
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(-3,0,4);
    railLine_func();
    glPopMatrix();
    glDisable(GL_TEXTURE_2D);

    //bridge
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    bridge_func();
    glPopMatrix();

    //road
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    road_func();
    glPopMatrix();

    //river
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    river_func();
    glPopMatrix();

    //sky
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    sky_func();
    glPopMatrix();

    //moi
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(10,-0.5,-4.5);
    glScalef(1,0.5,1);
    moi_func();
    glPopMatrix();

    //advanced
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(15,-0.5,-4.5);
    glScalef(1,0.7,1);
    moi_func_advanced();
    glPopMatrix();


    //sliding moi
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(16,-1,33);
    glRotatef(180,0,1,0);
    glScalef(1,0.5,1);
    sliding_moi_func();
    glPopMatrix();

    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(19,-1,33);
    glRotatef(180,0,1,0);
    glScalef(1,0.5,1);
    sliding_moi_func();
    glPopMatrix();


    //rotating_bike
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(0,2,5);
    glScalef(0.5, 0.5, 0.5);
    bike_func();
    glPopMatrix();
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(0,2,20);
    glScalef(0.5, 0.5, 0.5);
    bike_func();
    glPopMatrix();

    //dheki
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(5,0.2,-7);
    dheki_func();
    glPopMatrix();

    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(0,0.2,-7);
    dheki_func();
    glPopMatrix();

    //dolna
    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(25,0.2,-10);
    glRotatef(90,0,1,0);
    dolna_func();
    glPopMatrix();

    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(25,0.2,-5);
    glRotatef(90,0,1,0);
    dolna_func();
    glPopMatrix();

    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(25,0.2,23);
    glRotatef(90,0,1,0);
    dolna_func();
    glPopMatrix();

    glPushMatrix();
    glRotatef( theta, axis_x, axis_y, 0.0 );
    glRotatef( alpha, axis_x, axis_y, 0.0 );
    glTranslatef(25,0.2,28);
    glRotatef(90,0,1,0);
    dolna_func();
    glPopMatrix();

    glPopMatrix();//.....................................

    glFlush();
    glutSwapBuffers();
}

void myKeyboardFunc( unsigned char key, int x, int y )
{
    switch (key)
    {

    case 'p':
    case 'P':
        pRotate = !pRotate;
        uRotate = false;
        f_x=0.0;
        f_y=1.0;
        break;

    //movement (front, back, left, right, up, down)
    case 'w':
    case 'W':
        eye_z--;
        break;
    case 's':
    case 'S':
        eye_z++;
        break;
    case 'a':
    case 'A':
        eye_x-=0.5;
        break;

    case 'd':
    case 'D':
        eye_x++;
        break;

    case 'u':
    case 'U':
        eye_y++;
        break;

    case 'o':
    case 'O':
        eye_y--;
        break;

    //look(up, down, left, right)
    case 'i':
    case 'I':
        look_y++;
        break;
    case 'k':
    case 'K':
        look_y--;
        break;

    case 'j':
    case 'J':
        look_x--;
        break;

    case 'l':
    case 'L':
        look_x++;
        break;

    case 'h':
    case 'H':
        bRotate = !bRotate;
        uRotate = false;
        axis_x=0.0;
        axis_y=1.0;
        break;

    case 'v':
    case 'V':
        uRotate = !uRotate;
        bRotate = false;
        axis_x=1.0;
        axis_y=0.0;
        break;

    case '1':
        L0 = !L0;
        if(L0)
            glEnable(GL_LIGHT0);
        else
            glDisable(GL_LIGHT0);
        break;

    case '2':
        L1 = !L1;
        if(L1)
            glEnable(GL_LIGHT1);
        else
            glDisable(GL_LIGHT1);
        break;

    case '3':
        L2 = !L2;
        if(L2)
            glEnable(GL_LIGHT2);
        else
            glDisable(GL_LIGHT2);
        break;

    case '4':
        AL = !AL;
        light();
        break;
    case '5':
        DL = !DL;
        light();
        break;
    case '6':
        SL = !SL;
        light();
        break;

    case '7':
        gRotate = !gRotate;
        uRotate = false;
        bRotate = false;
        break;

    case '8':
        dkRotate = !dkRotate;
        uRotate = false;
        bRotate = false;
        d_x = 1.0;
        d_y = 0.0;
        break;

    case '9':
        dRotate = !dRotate;
        uRotate = false;
        bRotate = false;
        d_x = 1.0;
        d_y = 0.0;
        break;

    case 'f':
    case 'F':
        fanRotate = !fanRotate;
        uRotate = false;
        f_x=0.0;
        f_y=1.0;
        break;

    case '0':
        wired=!wired;
        break;

    case 27 ://escape key
        exit(0);
        break;
    }
}

void animate()
{
    light();

    mb+=0.05;    //boat
    if(mb>75)
        mb=-100;
    ms+=0.3;//ship
    if(ms>45)
        ms=-110;

    if(td==3)
        td=11;
    else if(td==11)
        td=12;
    else if(td==12)
        td=13;
    else
        td=3;

    //gari
    if(gRotate==true)
    {

        static bool ch1 = true, ch2 = false, ch3 = false, ch4 = false;
        if(ch1)
        {
            tz+=0.1;
            if(tz>35.2)
            {
                ch1 = false;
                ch2 = true;
                tr_rot=-90;

            }
        }
        if(ch2)
        {
            tx-=0.1;
            if(tx<-22)
            {
                ch2 = false;
                ch3 = true;
                tr_rot-=90;
            }
        }
        if(ch3)
        {
            tz-=0.1;
            if(tz<-10)
            {
                ch3 = false;
                ch4 = true;
                tr_rot-=90;
            }
        }
        if(ch4)
        {
            tx+=0.1;
            if(tx>-13)
            {
                ch4 = false;
                ch1 = true;
                tr_rot-=90;
            }
        }
    }

    //dheki
    if(dkRotate== true)
    {
        static bool ch = false, ch2 = true;
        if(d_rot<45.0 && ch2)
        {
            d_rot += 0.5;
        }
        else
            ch = true;
        if(ch && d_rot>-45.0)
        {
            d_rot -= 0.5;
            ch2 = false;
        }
        else
        {
            ch2 = true;
            ch = false;
        }
    }


    //dolna
    if(dRotate== true)
    {
        static bool ch = false, ch2 = true;
        if(rot<45.0 && ch2)
        {
            rot += 0.5;
        }
        else
            ch = true;
        if(ch && rot>-45.0)
        {
            rot -= 0.5;
            ch2 = false;
        }
        else
        {
            ch2 = true;
            ch = false;
        }
    }

    //horizontal
    if (bRotate == true)
    {
        theta += 0.3;
        if(theta > 360.0)
            theta -= 360.0*floor(theta/360.0);
    }

    //vertical
    if (uRotate == true)
    {
        alpha += 0.3;
        if(alpha > 360.0)
            alpha -= 360.0*floor(alpha/360.0);
    }
    //bike
    if (fanRotate == true)
    {
        fan_rot -= 0.5;
        if(fan_rot <= 0.0)
            fan_rot  = 360.0;
    }

    //peyala
    if (pRotate == true)
    {
        p_rot -= 0.5;
        if(p_rot <= 0.0)
            p_rot  = 360.0;
    }


    glutPostRedisplay();

}

int main (int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);

    glutInitWindowPosition(100,100);
    glutInitWindowSize(windowHeight, windowWidth);
    glutCreateWindow("Kids Park Project");

    printf("Enter below key for controlling....");
    printf("......................................................................\n");
    printf("1 light1(LEFT) Spotlight\t  2 light2(RIGHT)Spotlight \t 3 light3(top) \n");
    printf(" 4  ambient\t 5 diffuse\t 6 specular\n");
    printf("7 control car\t 8 control dheki\t9 control dolna\n");
    printf("f/F control rotating bike\tp control peyala\t 0 wire/fill\n");
    printf(" h/H horizontal rotation\n v/V vertical rotation");

    printf("\nEnter below key for controlling movement....fixed");
    printf("\n w/W  front\t s/S back");
    printf("\n a/A  left\t d/D right");
    printf("\n u/U  up\t o/O down");

    printf("\n\nEnter below key for controlling look....");
    printf("\n i/I up\t\t k/K down");
    printf("\n j/J  left\t l/L right");
    printf("\n\nEnter Esc for quit\n");

    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\red.bmp", &TID[0]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\black.bmp", &TID[1]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\metal.bmp", &TID[2]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\sea1.bmp", &TID[3]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\navy_blue.bmp", &TID[4]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\road.bmp", &TID[5]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\brick2.bmp", &TID[6]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\blue.bmp", &TID[7]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\sky.bmp", &TID[8]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\wooden.bmp", &TID[9]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\windows.bmp", &TID[10]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\sea2.bmp", &TID[11]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\sea3.bmp", &TID[12]);
    LoadTexture("E:\\4rth year 2nd semester\\graphics LAB\\GLUT projects\\Kids Park\\sea4.bmp", &TID[13]);
    td=3;


    glShadeModel( GL_SMOOTH );
    glEnable( GL_DEPTH_TEST );
    glEnable(GL_NORMALIZE);
    glEnable(GL_LIGHTING);

    glutKeyboardFunc(myKeyboardFunc);
    glutDisplayFunc(display);
    glutIdleFunc(animate);
    glutMainLoop();

    return EXIT_SUCCESS;
}





